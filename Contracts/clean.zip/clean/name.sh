i=1
for file in *.sol; do
  mv "$file" "temp_$i.sol"
  i=$((i + 1))
done

i=1
for file in temp_*.sol; do
  mv "$file" "$i.sol"
  i=$((i + 1))
done

