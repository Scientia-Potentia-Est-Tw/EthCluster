cp {1..122}.txt /home/antiransom/Unsupervised/Contracts/clean/122/

/home/antiransom/Unsupervised/Contracts/clean/1.sol