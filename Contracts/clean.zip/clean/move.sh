#!/bin/bash

target_directory_path="./"

if [ ! -d "$target_directory_path" ]; then
    echo "Target directory $target_directory_path does not exist. Creating it now."
    mkdir -p "$target_directory_path"
fi

for i in {1..1990}; do

    txt_file="/home/antiransom/Unsupervised/Contracts/SBcontracts/slither_filtered/mythril_result/${i}.txt"
    sol_file="/home/antiransom/Unsupervised/Contracts/SBcontracts/slither_filtered/${i}.sol"

    if [ -f "$txt_file" ] && [ $(stat -c %s "$txt_file") == 67 ]; then
	if [ -f "$sol_file" ]; then
	    echo "Moving $sol_file to $target_directory_path"
            cp "$sol_file" "$target_directory_path"
        else
            echo "No corresponding .sol file found for $txt_file"
        fi
    fi
done
